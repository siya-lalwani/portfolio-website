
import React from 'react';
import type { Skill, Project, EducationItem, ExperienceItem } from './types';

export const skillsData: Skill[] = [
  {
    title: 'ML Core',
    icon: (
      <svg className="w-10 h-10" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
        <circle cx="15" cy="10" r="4" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/>
        <circle cx="15" cy="40" r="4" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/>
        <circle cx="35" cy="25" r="4" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/>
        <line x1="15" y1="10" x2="35" y2="25" stroke="#374151" strokeWidth="2"/>
        <line x1="15" y1="40" x2="35" y2="25" stroke="#374151" strokeWidth="2"/>
        <text x="5" y="5" fontSize="8" className="handwritten" fill="#374151">ML</text>
      </svg>
    ),
    points: [
      '**Python** (Pandas, Scikit-learn)',
      '**Machine Learning:** Regression (Linear, Logistic), Classification (KNN)',
      '**Databases:** MySQL, MongoDB',
    ],
  },
  {
    title: 'Data & Viz',
    icon: (
      <svg className="w-10 h-10" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
        <line x1="5" y1="45" x2="45" y2="45" stroke="#374151" strokeWidth="2"/>
        <rect x="10" y="25" width="8" height="20" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/> 
        <rect x="25" y="15" width="8" height="30" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/>
        <rect x="40" y="35" width="8" height="10" fill="#fef08a" stroke="#374151" strokeWidth="1.5"/>
        <text x="10" y="10" fontSize="8" className="handwritten" fill="#374151">CHART</text>
      </svg>
    ),
    points: [
      '**Visualization:** Matplotlib, Seaborn',
      '**EDA** (Exploratory Data Analysis)',
      '**Python Frameworks:** Django, Flask',
    ],
  },
  {
    title: 'Web & Design',
    icon: (
      <svg className="w-10 h-10" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
        <polyline points="10 10 5 25 10 40" className="doodle-stroke" stroke="#374151" strokeWidth="3" fill="none"/>
        <polyline points="40 10 45 25 40 40" className="doodle-stroke" stroke="#374151" strokeWidth="3" fill="none"/>
        <circle cx="25" cy="25" r="10" fill="#fef08a" stroke="#374151" strokeWidth="3"/>
        <text x="15" y="10" fontSize="8" className="handwritten" fill="#374151">FIGMA</text>
      </svg>
    ),
    points: [
      '**Frontend:** HTML, CSS, JavaScript',
      '**Design:** Figma (Prototyping)',
      '**PHP** Development',
    ],
  },
];

export const projectsData: Project[] = [
    {
        title: "Movie Reco System",
        subtitle: "COLLABORATIVE FILTERING",
        icon: (
            <svg className="w-20 h-20 text-yellow-500 mx-auto" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="#374151" strokeWidth="2" fill="#fef08a"/>
                <circle cx="12" cy="12" r="2" fill="#fef08a"/>
            </svg>
        ),
        description: "Built a **collaborative filtering** recommendation system that predicts user ratings and suggests movies. This involved extensive **data preprocessing** and **similarity calculations** using core Python libraries, leading to visually evaluated results.",
        tags: [
            { text: "Python", color: "yellow" },
            { text: "Scikit-learn", color: "yellow" },
            { text: "Collaborative Filtering", color: "yellow" },
        ],
    },
    {
        title: "Population Trends",
        subtitle: "EXPLORATORY DATA ANALYSIS",
        icon: (
            <svg className="w-20 h-20 text-yellow-500 mx-auto" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <circle cx="12" cy="12" r="10" stroke="#374151" strokeWidth="2" fill="#fef08a"/>
                <path d="M12 2a15 15 0 010 20" stroke="#374151" strokeWidth="2"/>
                <path d="M2.5 12h19" stroke="#374151" strokeWidth="2"/>
            </svg>
        ),
        description: "Executed a comprehensive **Exploratory Data Analysis (EDA)** to study global population trends and demographic patterns. Key findings were visually represented using **Matplotlib and Seaborn**, effectively highlighting regional growth and future projections.",
        tags: [
            { text: "EDA", color: "pink" },
            { text: "Matplotlib/Seaborn", color: "pink" },
            { text: "Statistics", color: "pink" },
        ],
    },
    {
        title: "Stock Analysis",
        subtitle: "TIME SERIES FORECASTING",
        icon: (
            <svg className="w-20 h-20 text-yellow-500 mx-auto" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <rect x="5" y="10" width="4" height="8" fill="#fef08a" stroke="#374151" strokeWidth="2"/>
                <line x1="7" y1="5" x2="7" y2="10" stroke="#374151" strokeWidth="2"/>
                <rect x="15" y="5" width="4" height="12" fill="#fef08a" stroke="#374151" strokeWidth="2"/>
                <line x1="17" y1="17" x2="17" y2="22" stroke="#374151" strokeWidth="2"/>
            </svg>
        ),
        description: "Conducted time series analysis to identify stock trends and forecast future prices. Implemented **moving averages, trend lines, and pattern analysis** using Python, Pandas, and NumPy for robust, data-backed market insights.",
        tags: [
            { text: "Time Series", color: "yellow" },
            { text: "Pandas/NumPy", color: "yellow" },
            { text: "Forecasting", color: "yellow" },
        ],
    }
];

export const educationData: EducationItem[] = [
    {
        degree: 'Integrated MSc Computer Science',
        institution: 'Gujarat University',
        details: 'Aug 2023 - July 2028',
    },
    {
        degree: 'Higher Secondary School Certificate',
        institution: 'Airport School Ahmedabad',
        details: '90.4%',
    }
];

export const experienceData: ExperienceItem[] = [
    {
        role: 'Content and Digital Media Intern',
        company: 'Gujarat Student Startup and Innovation hub (i-Hub)',
        duration: 'Oct 2024 - Dec 2024',
        points: [
            'Assisted 5+ DeepTech startups for grant support.',
            'Coordinated 25+ pitching sessions.',
        ]
    }
];
