
import type React from 'react';

export interface Skill {
  title: string;
  icon: React.ReactNode;
  points: string[];
}

export interface Project {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  description: string;
  tags: {
    text: string;
    color: 'pink' | 'yellow';
  }[];
}

export interface EducationItem {
  degree: string;
  institution: string;
  details: string;
}

export interface ExperienceItem {
    role: string;
    company: string;
    duration: string;
    points: string[];
}
