
import React from 'react';
import { skillsData } from '../constants';
import BoldText from './shared/BoldText';

const Skills: React.FC = () => {
    return (
        <section id="skills" className="mt-16">
            <h2 className="text-5xl font-extrabold mb-12 text-center quirky-header structural-accent">
                My Creative <span className="bg-yellow-200 px-2 rounded-lg -rotate-2 inline-block opacity-70">Toolkit</span>
            </h2>
            
            <div className="grid md:grid-cols-3 gap-6">
                {skillsData.map((skill, index) => (
                    <div key={index} className="bg-white illustrated-card p-6 md:p-8 border-pink-500">
                        <div className="flex items-center space-x-3 mb-4 border-b-2 pb-2 border-pink-500">
                            {skill.icon}
                            <h3 className="text-2xl font-bold quirky-header main-accent">{skill.title}</h3>
                        </div>
                        <ul className="text-gray-600 space-y-2 text-lg mt-4">
                           {skill.points.map((point, i) => (
                                <BoldText key={i} as="li" text={point} />
                           ))}
                        </ul>
                    </div>
                ))}
            </div>
        </section>
    );
};

export default Skills;
