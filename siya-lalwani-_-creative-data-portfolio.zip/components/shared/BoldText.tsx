
import React from 'react';

interface BoldTextProps {
  text: string;
  as: 'p' | 'li' | 'span';
  className?: string;
}

const BoldText: React.FC<BoldTextProps> = ({ text, as: Component, className }) => {
  const parts = text.split('**');
  
  return (
    <Component className={className}>
      {parts.map((part, index) =>
        index % 2 === 1 ? <strong key={index}>{part}</strong> : <React.Fragment key={index}>{part}</React.Fragment>
      )}
    </Component>
  );
};

export default BoldText;
