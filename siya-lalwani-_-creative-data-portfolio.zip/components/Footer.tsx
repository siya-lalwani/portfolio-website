
import React from 'react';

const Footer: React.FC = () => {
    return (
        <footer id="contact" className="mt-16 pt-8 pb-12 text-center bg-white illustrated-card p-12 border-pink-500">
            <h2 className="text-5xl font-extrabold mb-4 text-gray-800 quirky-header">
                Let's Make <span className="bg-pink-300 px-2 rounded-lg -rotate-1 inline-block opacity-70">Something Super Useful!</span>
            </h2>
            <p className="text-gray-600 mb-8 max-w-2xl mx-auto text-xl">
                I'm always open to new projects that push the boundaries of data science and creative problem-solving. Let's collaborate.
            </p>

            <div className="flex justify-center items-center flex-wrap gap-y-4 gap-x-8 text-xl">
                <a href="mailto:Siyalalwani.wp@gmail.com" className="text-gray-600 hover:text-pink-500 transition duration-300 font-semibold border-b border-dashed border-gray-400">
                    Siyalalwani.wp@gmail.com
                </a>
                <a href="https://github.com/siya-lalwani" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-pink-500 transition duration-300 font-semibold border-b border-dashed border-gray-400">
                    GitHub Profile
                </a>
            </div>
        </footer>
    );
};

export default Footer;
