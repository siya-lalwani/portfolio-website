
import React from 'react';
import { educationData, experienceData } from '../constants';

const Experience: React.FC = () => {
    return (
        <section id="experience" className="mt-16">
            <h2 className="text-5xl font-extrabold mb-12 text-center quirky-header structural-accent">
                Journey <span className="main-accent">Log</span>
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-white illustrated-card p-8 border-pink-500">
                    <h3 className="text-3xl font-bold mb-4 border-b-4 pb-2 border-pink-500 quirky-header main-accent">Education</h3>
                    <div className="space-y-6">
                        {educationData.map((edu, index) => (
                            <div key={index} className="p-4 bg-yellow-50 rounded-lg border border-gray-300"> 
                                <p className="font-bold text-xl">{edu.degree}</p>
                                <p className="text-sm text-gray-700 italic">{edu.institution} | {edu.details}</p>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="bg-white illustrated-card p-8 border-pink-500">
                    <h3 className="text-3xl font-bold mb-4 border-b-4 pb-2 border-pink-500 quirky-header main-accent">Experience</h3>
                    <div className="space-y-6">
                        {experienceData.map((exp, index) => (
                             <div key={index} className="p-4 bg-yellow-50 rounded-lg border border-gray-300">
                                <p className="font-bold text-xl">{exp.role}</p>
                                <p className="text-sm text-gray-700 italic mb-2">{exp.company} | {exp.duration}</p>
                                <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                                    {exp.points.map((point, i) => (
                                        <li key={i}>{point}</li>
                                    ))}
                                </ul>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Experience;
