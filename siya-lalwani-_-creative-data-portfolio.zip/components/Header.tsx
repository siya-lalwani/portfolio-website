
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="flex justify-between items-center py-6 sticky top-0 z-10 bg-[#fffefc] border-b border-gray-100">
            <a href="#" className="text-4xl font-extrabold structural-accent quirky-header">
                SIYA <span className="main-accent">LALWANI</span>
            </a>
            <nav className="space-x-4 text-lg font-medium hidden sm:block">
                <a href="#projects" className="hover:text-pink-500 transition duration-300">Projects</a>
                <a href="#skills" className="hover:text-pink-500 transition duration-300">Skills</a>
                <a href="#contact" className="hover:text-pink-500 transition duration-300">Say Hi!</a>
            </nav>
        </header>
    );
};

export default Header;
