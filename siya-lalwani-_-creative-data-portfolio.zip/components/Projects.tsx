
import React from 'react';
import { projectsData } from '../constants';
import BoldText from './shared/BoldText';

const Projects: React.FC = () => {
    return (
        <section id="projects" className="mt-16">
            <h2 className="text-5xl font-extrabold mb-12 text-center quirky-header structural-accent">
                My <span className="text-pink-500">Impactful</span> Projects
            </h2>

            <div className="space-y-8">
                {projectsData.map((project, index) => (
                    <div key={index} className="bg-white illustrated-card p-6 md:p-8 flex flex-col md:flex-row gap-6 border-pink-500">
                        <div className="flex-shrink-0 w-full md:w-1/3 p-4 bg-pink-50 rounded-lg border-2 border-pink-300 flex flex-col justify-center">
                             <h3 className="text-3xl font-bold mb-2 text-pink-600 quirky-header">{project.title}</h3>
                             <p className="text-xs text-gray-500 mb-4">{project.subtitle}</p>
                             {project.icon}
                        </div>
                        <div className="md:w-2/3">
                            <BoldText text={project.description} as="p" className="text-gray-700 leading-relaxed text-lg"/>
                            <div className="mt-4 flex flex-wrap gap-2">
                                {project.tags.map((tag, i) => (
                                    <span key={i} className={`project-tag-${tag.color}`}>
                                        {tag.text}
                                    </span>
                                ))}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </section>
    );
};

export default Projects;
